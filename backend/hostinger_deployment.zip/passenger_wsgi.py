from app import app as application

# This is required for Hostinger's Python hosting
application = application
